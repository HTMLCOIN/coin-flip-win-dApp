# Flipper 
Smart contract for Flipper dApp
