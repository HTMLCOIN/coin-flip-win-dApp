# Flipper

Betting dApp, with different role categories(owner/player), that allows players to gamble on a 50% winning chance. On the initial load, the player is automatically asked to connect to his/her MetaMask wallet. The user is able to place multiple bets and the winnings are added to his/her contract account. Funds can be manually withdrawn to avoid multiple network fees.

`npm run deploy`
